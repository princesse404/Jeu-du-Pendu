import sys
import random
import threading
import time
import colorama
from colorama import Fore, Back

ascii_art = """"

██████████████████████████████████████████████████████████████████████
███▄─▄█▄─▄▄─█▄─██─▄███▄─▄▄▀█▄─██─▄███▄─▄▄─█▄─▄▄─█▄─▀█▄─▄█▄─▄▄▀█▄─██─▄█
█─▄█─███─▄█▀██─██─█████─██─██─██─█████─▄▄▄██─▄█▀██─█▄▀─███─██─██─██─██
█▄▄▄███▄▄▄▄▄██▄▄▄▄████▄▄▄▄███▄▄▄▄████▄▄▄███▄▄▄▄▄█▄▄▄██▄▄█▄▄▄▄███▄▄▄▄██ par Dor.mth
"""

def fin_prog() :
    print("temps ecouler dommage")
timer = threading.Timer(60 , fin_prog)

choix = 1
niveaudi = ""
mot_random = []

def clear() :
    sys.stdout.write("\033[H\033[J")
    sys.stdout.flush()

with open('./game.py') as fichier:
    code = fichier.read()

def cchoix(mode):
    if mode == 1:
        with open("./liste/liste_facile.txt", "r") as fichier:
            mot = fichier.read().splitlines()
        return mot

    if mode == 2:
        with open("./liste/liste_normal.txt", "r") as fichier:
            mot = fichier.read().splitlines()
        return mot

    if mode == 3:
        with open("./liste/liste_difficile.txt", "r") as fichier:
            mot = fichier.read().splitlines()
        return mot

    if mode == 4:
        with open("./liste/liste_difficile.txt", "r") as fichier:
            mot = fichier.read().splitlines()
        return mot

    else:
        print("Mode invalide.")
        return []

print(Fore.CYAN , Back.BLACK , ascii_art , """
Selectionnez un mode de jeu : (1) Facile, (2) Normal, (3) Difficile , (4) Defi""")
mode = int(input("$:"))
clear()
while choix == 1 :
    if mode == 1 :
        niveaudi = "Facile"
    if mode == 2 :
        niveaudi = "Normal"
    if mode == 3 :
        niveaudi = "Difficile"
    if mode == 4 :
        niveaudi = "Defi"

    mots = cchoix(mode)

    if not mots:
        print(ascii_art)
        print("Erreur : liste de mots vide ou mode invalide.")
        break
    solution = random.choice(mots)
    while solution in mot_random :
        solution = random.choice(mots)
    mot_random.append(solution)
    if mode == 4 :
        print(Fore.RED , Back.BLACK , ascii_art)
        print("MODE DEFI vous avez 60 seconde pour gagner !")
        start = input("lancer le jeu")
        while True :
            time.sleep(1)
            timer.start()
            exec(code)

    else :
        exec(code)
    print("Voulez-vous continuer de jouer ? (1) Oui, (2) Non")
    choix = int(input("$:"))
    if choix != 1 :
        exit()
    clear()
    print(ascii_art)
    print("voulez vous changer de mode de difficulte ? (1) Oui , (2) Non")
    cnt = int(input("$:"))
    if cnt == 1 :
        clear()
        print(ascii_art)
        print("Selectionnez un mode de jeu : (1) Facile, (2) Normal, (3) Difficile , (4) Defi")
        mode = int(input("$:"))
        clear()
    else:
        clear()
        print(ascii_art)
        print("Mode invalide.")

exit()