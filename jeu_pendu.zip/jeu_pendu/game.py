import json
import sys
import colorama
from colorama import Fore, Back

ascii_art = """"

██████████████████████████████████████████████████████████████████████
███▄─▄█▄─▄▄─█▄─██─▄███▄─▄▄▀█▄─██─▄███▄─▄▄─█▄─▄▄─█▄─▀█▄─▄█▄─▄▄▀█▄─██─▄█
█─▄█─███─▄█▀██─██─█████─██─██─██─█████─▄▄▄██─▄█▀██─█▄▀─███─██─██─██─██
█▄▄▄███▄▄▄▄▄██▄▄▄▄████▄▄▄▄███▄▄▄▄████▄▄▄███▄▄▄▄▄█▄▄▄██▄▄█▄▄▄▄███▄▄▄▄██ par Dor.mth
"""

tentatives = 7
lettres_utilisees = []
affichage = ""
lettres_trouvees = ""
search = 0

def clear() :
    sys.stdout.write("\033[H\033[J")
    sys.stdout.flush()

for lettre in solution:
    affichage += "_ "

while tentatives > 0:
    if search == 0 :
        print(ascii_art)
    print("Mot a deviner : ", affichage)
    print("Lettre deja utilisee : " , lettres_utilisees)
    print("Proposez une lettre : ")
    proposition = input("$:").lower()
    search += 1

    if proposition in lettres_utilisees:
        clear()
        print(ascii_art)
        print("Lettre deje utilisee.")
        continue

    if proposition in solution:
        lettres_utilisees.append(proposition)
        lettres_trouvees += proposition
        clear()
        print(ascii_art)
        print("C'est juste !")
    else:
        lettres_utilisees.append(proposition)
        tentatives -= 1
        clear()
        print(ascii_art)
        print("Faux, il vous reste", tentatives, "tentatives.")

    if tentatives==0:
        print(" ==========Y= ")
    if tentatives<=1:
        print(" ||/       |  ")
    if tentatives<=2:
        print(" ||        0  ")
    if tentatives<=3:
        print(" ||       /|/ ")
    if tentatives<=4:
        print(" ||       /|  ")
    if tentatives<=5:                    
        print("/||           ")
    if tentatives<=6:
        print("==============")
    if tentatives==0:
        print("perdu le mot etait " , solution)
        break

    affichage = ""
    for lettre in solution:
        if lettre in lettres_trouvees:
            affichage += lettre + " "
        else:
            affichage += "_ "

    if "_" not in affichage:
            print("Gagne ! Le mot etait :", solution)
            break